from setuptools import setup, find_packages
setup(name="testpkg", version="1.0.dev777xyz", packages=find_packages())
