import time
time.sleep(30)
from setuptools import setup
setup(name="sleeppkg", version="1.0")
